let tipoUsuario = document.querySelector("#login").value;
console.log(tipoUsuario);
console.log("dat")